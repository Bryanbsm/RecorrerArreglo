/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recorrerarreglo;

/**
 *
 * @author Lenovo
 */
public class RecorrerArreglo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

   /*
   ClaseArray a = new ClaseArray();
        a.agregarDatos(500000);
       // a.recorrerFOR();
        a.recorrerForEach();
        */
   
   InterfazArreglo ia = new InterfazArreglo();
   ia.setVisible(true);
    }
    
}
